-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `l_lessons`
--

DROP TABLE IF EXISTS `l_lessons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `l_lessons` (
  `l_c_class` varchar(6) NOT NULL,
  `l_hour` varchar(4) NOT NULL,
  `l_s_subject` int NOT NULL,
  `l_t_teacher` char(5) NOT NULL,
  `l_r_room` varchar(6) NOT NULL,
  PRIMARY KEY (`l_c_class`,`l_hour`,`l_s_subject`),
  KEY `fk_l_lessons_r_rooms1_idx` (`l_r_room`),
  KEY `fk_l_lessons_s_subjects1_idx` (`l_s_subject`),
  KEY `fk_l_lessons_t_teachers1_idx` (`l_t_teacher`),
  KEY `fk_l_lessons_c_class1_idx` (`l_c_class`),
  CONSTRAINT `fk_l_lessons_c_class1` FOREIGN KEY (`l_c_class`) REFERENCES `c_classes` (`c_id`),
  CONSTRAINT `fk_l_lessons_r_rooms1` FOREIGN KEY (`l_r_room`) REFERENCES `r_rooms` (`r_id`),
  CONSTRAINT `fk_l_lessons_s_subjects1` FOREIGN KEY (`l_s_subject`) REFERENCES `s_subjects` (`s_id`),
  CONSTRAINT `fk_l_lessons_t_teachers1` FOREIGN KEY (`l_t_teacher`) REFERENCES `t_teachers` (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `l_lessons`
--

LOCK TABLES `l_lessons` WRITE;
/*!40000 ALTER TABLE `l_lessons` DISABLE KEYS */;
INSERT INTO `l_lessons` VALUES ('03TA','B1',0,'DO1','B1'),('03TA','BE',0,'DO4','LA1'),('03TA','BI',0,'DI1','B1'),('03TA','HA',0,'DI3','LA3'),('03TA','LI',0,'MO1','B1'),('03TA','PS',0,'MI1','LA2'),('03TB','B1',0,'DO3','B2'),('03TB','BE',0,'MO4','B2'),('03TB','BI',0,'MI1','B2'),('03TB','HA',0,'DI3','LA2'),('03TB','LI',0,'MI4','B2'),('03TB','PS',0,'DI1','LA1');
/*!40000 ALTER TABLE `l_lessons` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:20
