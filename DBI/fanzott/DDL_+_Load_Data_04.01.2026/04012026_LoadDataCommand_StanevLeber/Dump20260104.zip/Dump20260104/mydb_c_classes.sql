-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `c_classes`
--

DROP TABLE IF EXISTS `c_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_classes` (
  `c_id` varchar(6) NOT NULL,
  `c_text` varchar(45) DEFAULT NULL,
  `c_t_classteacher` char(5) NOT NULL,
  `c_p_classrepsubst` int NOT NULL,
  `c_p_classrep` int NOT NULL,
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `c_p_classrep_UNIQUE` (`c_p_classrep`),
  UNIQUE KEY `c_p_classrepsubst_UNIQUE` (`c_p_classrepsubst`),
  KEY `fk_c_class_t_teachers1_idx` (`c_t_classteacher`),
  KEY `fk_c_class_p_pupils2_idx` (`c_p_classrepsubst`),
  KEY `fk_c_class_p_pupils1_idx` (`c_p_classrep`),
  CONSTRAINT `fk_c_class_p_pupils1` FOREIGN KEY (`c_p_classrep`) REFERENCES `p_pupils` (`p_pupilnr`),
  CONSTRAINT `fk_c_class_p_pupils2` FOREIGN KEY (`c_p_classrepsubst`) REFERENCES `p_pupils` (`p_pupilnr`),
  CONSTRAINT `fk_c_class_t_teachers1` FOREIGN KEY (`c_t_classteacher`) REFERENCES `t_teachers` (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_classes`
--

LOCK TABLES `c_classes` WRITE;
/*!40000 ALTER TABLE `c_classes` DISABLE KEYS */;
INSERT INTO `c_classes` VALUES ('01VL','Vorber.LG','0',0,0);
/*!40000 ALTER TABLE `c_classes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:19
