-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `e_exams`
--

DROP TABLE IF EXISTS `e_exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `e_exams` (
  `e_date` date NOT NULL,
  `e_p_cand` int NOT NULL,
  `e_s_subject` int NOT NULL,
  `e_t_teacher` char(5) NOT NULL,
  `e_type` enum('WP','FP') NOT NULL,
  `e_mark` int DEFAULT NULL,
  PRIMARY KEY (`e_date`,`e_p_cand`,`e_s_subject`),
  KEY `fk_e_exams_s_subjects1_idx` (`e_s_subject`),
  KEY `fk_e_exams_p_pupils1_idx` (`e_p_cand`),
  KEY `fk_e_exams_t_teachers1_idx` (`e_t_teacher`),
  CONSTRAINT `fk_e_exams_p_pupils1` FOREIGN KEY (`e_p_cand`) REFERENCES `p_pupils` (`p_pupilnr`),
  CONSTRAINT `fk_e_exams_s_subjects1` FOREIGN KEY (`e_s_subject`) REFERENCES `s_subjects` (`s_id`),
  CONSTRAINT `fk_e_exams_t_teachers1` FOREIGN KEY (`e_t_teacher`) REFERENCES `t_teachers` (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_exams`
--

LOCK TABLES `e_exams` WRITE;
/*!40000 ALTER TABLE `e_exams` DISABLE KEYS */;
INSERT INTO `e_exams` VALUES ('0000-00-00',1987,0,'TDO','',5),('0000-00-00',1988,0,'TDO','',1),('0000-00-00',1989,0,'BO','',2);
/*!40000 ALTER TABLE `e_exams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:20
