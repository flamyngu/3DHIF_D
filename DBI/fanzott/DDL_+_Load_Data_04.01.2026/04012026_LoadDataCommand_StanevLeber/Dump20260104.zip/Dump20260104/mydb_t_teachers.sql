-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_teachers`
--

DROP TABLE IF EXISTS `t_teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_teachers` (
  `t_id` char(5) NOT NULL,
  `t_name` varchar(45) NOT NULL,
  `t_firstname` varchar(45) NOT NULL,
  `t_birthdate` date DEFAULT NULL,
  `t_salary` decimal(10,0) DEFAULT NULL,
  `t_t_boss` char(5) NOT NULL,
  PRIMARY KEY (`t_id`),
  KEY `fk_t_teachers_t_teachers_idx` (`t_t_boss`),
  CONSTRAINT `fk_t_teachers_t_teachers` FOREIGN KEY (`t_t_boss`) REFERENCES `t_teachers` (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_teachers`
--

LOCK TABLES `t_teachers` WRITE;
/*!40000 ALTER TABLE `t_teachers` DISABLE KEYS */;
INSERT INTO `t_teachers` VALUES ('AS','Aschauer','Anton','1961-08-09',180,'PI'),('AU','Auwald','Herbert','1946-09-07',150,'LN'),('B1','Berger','Alfred','1945-02-03',400,'null'),('BE','Beringer','Alfred','1961-07-15',220,'HA'),('BI','Bilek','Hans','1932-03-03',280,'HA'),('HA','Hanke','Gustav','1950-12-12',300,'B1'),('LI','Lindner','Kristine','1958-12-12',300,'HA'),('LN','Lenau','Nikolaus','1938-02-22',180,'HA'),('MY','Mayer','Walter','1947-04-01',120,'LN'),('PI','Pirkner','Walter','1955-06-26',220,'B1'),('PS','Prei','Johann','1956-07-05',82,'HA'),('SG','Siegel','Heinz','1954-10-05',120,'HA'),('WA','Walter','Hans','1949-11-11',115,'PI');
/*!40000 ALTER TABLE `t_teachers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:20
