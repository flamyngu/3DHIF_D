-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `p_pupils`
--

DROP TABLE IF EXISTS `p_pupils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `p_pupils` (
  `p_pupilnr` int NOT NULL,
  `p_name` varchar(45) NOT NULL,
  `p_firstname` varchar(45) NOT NULL,
  `p_birthdate` date NOT NULL,
  `p_address` varchar(45) DEFAULT NULL,
  `p_c_class` varchar(6) NOT NULL,
  PRIMARY KEY (`p_pupilnr`),
  KEY `fk_p_pupils_c_class1_idx` (`p_c_class`),
  CONSTRAINT `fk_p_pupils_c_class1` FOREIGN KEY (`p_c_class`) REFERENCES `c_classes` (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_pupils`
--

LOCK TABLES `p_pupils` WRITE;
/*!40000 ALTER TABLE `p_pupils` DISABLE KEYS */;
INSERT INTO `p_pupils` VALUES (1,'Adler','Richard','1966-03-12','Gumpendorf','03TA'),(4,'Kneippp','Sebastian','1967-12-24','Fuenfhaus','03TA'),(16,'Geyer','Walli','1966-07-23','Simmering','01VL'),(19,'Sitzenbleiber','Eusebius','1951-02-22','Schweiz','03TA'),(22,'Huber','Seppl','1968-02-02','Margareten','03TA'),(55,'Schulz','Xandl','1964-09-03','Doebling','03TB'),(74,'Hundertwasser','Friederike','1961-02-02','Landstrasse','03TA'),(77,'Berger','Balduin','1964-03-13','Favoriten','03TB'),(84,'Feuerstein','Bebbles','1966-06-12','Steintal','03TB'),(88,'Mayer','Barbara','1965-05-03','Ottakring','03TB'),(111,'Sandler','Eberhard','1959-04-19','Hoechststaettpl','03TB'),(122,'Graf','Bobby','1962-01-01','Doebling','03TA'),(1266,'Schlager','Ronnie','1963-04-23','Ottakring','03TB');
/*!40000 ALTER TABLE `p_pupils` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:20
