-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_bosses`
--

DROP TABLE IF EXISTS `b_bosses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_bosses` (
  `b_t_subordinate` char(5) NOT NULL,
  `b_type` varchar(45) NOT NULL,
  `b_t_boss` char(5) NOT NULL,
  PRIMARY KEY (`b_t_subordinate`,`b_type`),
  KEY `fk_b_bosses_t_teachers1_idx` (`b_t_boss`),
  KEY `fk_b_bosses_t_teachers2_idx` (`b_t_subordinate`),
  CONSTRAINT `fk_b_bosses_t_teachers1` FOREIGN KEY (`b_t_boss`) REFERENCES `t_teachers` (`t_id`),
  CONSTRAINT `fk_b_bosses_t_teachers2` FOREIGN KEY (`b_t_subordinate`) REFERENCES `t_teachers` (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_bosses`
--

LOCK TABLES `b_bosses` WRITE;
/*!40000 ALTER TABLE `b_bosses` DISABLE KEYS */;
INSERT INTO `b_bosses` VALUES ('BE','Direktor','B1'),('BI','Direktor','B1'),('HA','Direktor','B1'),('LI','Direktor','B1'),('PS','Direktor','B1'),('PS','Fgrp Prog','BE'),('LI','Fgrp RW','BI'),('BE','AV','HA'),('BI','AV','HA'),('LI','AV','HA'),('PS','AV','HA');
/*!40000 ALTER TABLE `b_bosses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-04 21:22:20
